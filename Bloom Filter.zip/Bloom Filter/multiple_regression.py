# Refrenced from - https://faun.pub/implementing-multiple-linear-regression-from-scratch-in-python-f5d84d4935bb
# data from kaggle

# Objective - find the right set of investment on R&D,Administration & Marketing to achieve the Profit target

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import OneHotEncoder, StandardScaler

class GradientDescentRegression:
    def __init__(self, learning_rate=0.002, epochs=15000):
        self.learning_rate = learning_rate
        self.epochs = epochs
        self.w = None
        self.b = None
        self.cost_list = []

    def fit(self, X, y):
        self.w = np.zeros(X.shape[1])
        self.b = 0

        for epoch in range(self.epochs):
            z = X.dot(self.w) + self.b
            loss = z - y

            weight_gradient = X.T.dot(loss) / len(y)
            bias_gradient = np.sum(loss) / len(y)

            self.w = self.w - self.learning_rate * weight_gradient
            self.b = self.b - self.learning_rate * bias_gradient

            cost = self.cost_function(X, y)
            self.cost_list.append(cost)

            if (epoch % (self.epochs / 10) == 0):
                print("Cost at epoch", epoch, "is:", cost)

    def predict(self, X):
        return X.dot(self.w) + self.b

    def r2score(self, y_pred, y):
        rss = np.sum((y_pred - y) ** 2)
        tss = np.sum((y - y.mean()) ** 2)

        r2 = 1 - (rss / tss)
        return r2

    def cost_function(self, X, y):
        cost = np.sum((((X.dot(self.w) + self.b) - y) ** 2) / (2 * len(y)))
        return cost

if __name__ == '__main__':
    # Input the data set
    df = pd.read_csv(r"C:\Users\ashutoshp\Documents\Python Scripts\MTech\MM_M22AI529_MiniProject3\50_Startups.csv")

    # In case you want to view data plots un-comment the following lines
    fig, ax = plt.subplots(nrows=2, ncols=2, figsize=(8, 8))
    fig.figsize = (10, 10)
    ax[0, 0].scatter(df['Profit'], df['R&D Spend'], color='red')
    ax[0, 1].scatter(df['Profit'], df['Administration'], color='yellow')
    ax[1, 0].scatter(df['Profit'], df['Marketing Spend'], color='green')
    ax[1, 1].scatter(df['Profit'], df['State'], color='blue')
    plt.tight_layout()
    plt.show()

    # Define features and labels
    X = df.iloc[:, :-1].values
    y = df.iloc[:, -1].values

    # Convert text data to numbers
    ct = ColumnTransformer(transformers=[('encoder', OneHotEncoder(), [3])], remainder='passthrough')
    X = np.array(ct.fit_transform(X))

    # Scale the dataset
    sc = StandardScaler()
    X = sc.fit_transform(X)

    # Separate the dataset into training and testing
    Xtrain, Xtest, Ytrain, Ytest = train_test_split(X, y, test_size=0.3, random_state=42)

    # Creating the Gradient Descent regression object
    gd_regression = GradientDescentRegression()

    # Calculating weights and bias
    gd_regression.fit(Xtrain, Ytrain)

    # Plotting the cost
    plt.plot(gd_regression.cost_list)
    plt.show()

    # Predicting labels with the calculated weights and biases
    y_pred = gd_regression.predict(Xtest)
    
    # Calculating the r² accuracy of our model
    print(gd_regression.r2score(y_pred,Ytest))
    

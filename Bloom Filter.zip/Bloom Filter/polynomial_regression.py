# Refrenced from - https://www.geeksforgeeks.org/python-implementation-of-polynomial-regression/

# Importing the libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score
from sklearn.model_selection import train_test_split

class PR:
    """
    A class for polynomial regression.
    Important characteristics:
    1. Required feature variables (x_data): 1
    2. Required target variables (y_data): 1
    3. Sample count (m): N
    """
    def __init__(self, degree):
        """
        degree type: int
        """
        self.n = degree # degree of the polynomial
        self.b = None   # weights (to be evaluated)
        self.poly_features = PolynomialFeatures(degree=self.n)
        self.poly_model = LinearRegression()
        
    def transform_data(self, data):
        return self.poly_features.fit_transform(data)
    
    def fit(self, x_data, y_data):
        # transforms the existing features to higher degree features.
        x_train_poly = self.transform_data(x_data)
  
        # fit the transformed features to Linear Regression
        self.poly_model.fit(x_train_poly, y_data)
        
    def predict(self, new_x, true_y=None):
        """
        1. This function should return predicted values for y.
        2. If true_y is not None -> then print the error as well
        """
        y_predicted = self.poly_model.predict(self.transform_data(new_x))
        if true_y is not None:
            rmse = np.sqrt(mean_squared_error(true_y, y_predicted))
            print(f"Root Mean Squared Error: {rmse}")
        return y_predicted


# Importing the dataset
df = pd.read_csv(r"C:\Users\ashutoshp\Documents\Python Scripts\MTech\MM_M22AI529_MiniProject3\data.csv")
#df.head()

# dependent and independent variables
x = df.iloc[:, 0].values.reshape(-1, 1)
y = df.iloc[:, 1].values.reshape(-1, 1)

# train-test split 75-25 ratio
x_train, x_test, y_train, y_test = train_test_split(x, y, random_state=0, train_size=.75)

# Results
summary = pd.DataFrame()
train_rmse = []
test_rmse = []

for i in range(1,11):
    # Creates a polynomial regression model for the given degree
    pr = PR(degree=i)
    pr.fit(x_train, y_train)
  
    # predicting on training data-set
    y_train_predicted = pr.predict(x_train)
  
    # predicting on test data-set
    y_test_predict = pr.predict(x_test)
  
    # evaluating the model on training dataset
    rmse_train = np.sqrt(mean_squared_error(y_train, y_train_predicted))
    r2_train = r2_score(y_train, y_train_predicted)
  
    # evaluating the model on test dataset
    rmse_test = np.sqrt(mean_squared_error(y_test, y_test_predict))
    r2_test = r2_score(y_test, y_test_predict)

    summary[str(i)+'_degree poly'] = [rmse_train,r2_train,rmse_test,r2_test]
    summary.index = ['rmse_train','r2_train','rmse_test','r2_test']

    train_rmse.append(rmse_train)
    test_rmse.append(rmse_test)

print(summary)

# Visualising the Polynomial Regression results

degree = [1,2,3,4,5,6,7,8,9,10]
plt.plot(train_rmse,degree,label='RMSE on train Data')
# plt.plot(test_rmse,degree,label='RMSE on test Data')
plt.title('Polynomial Regression')
plt.xlabel('RMSE_Score')
plt.ylabel('Polynomial_Degree')
plt.legend()
plt.show()

# Visualising the Polynomial Regression results

degree = [1,2,3,4,5,6,7,8,9,10]
# plt.plot(train_rmse,degree,label='RMSE on train Data')
plt.plot(test_rmse,degree,label='RMSE on test Data',color='g')
plt.title('Polynomial Regression')
plt.xlabel('RMSE_Score')
plt.ylabel('Polynomial_Degree')
plt.legend()
plt.show()

# =============================================================================
# From the above analysis we can see that for the given data - 2nd degree polynomial is best suited. The favouring points would be -
# 
# 
# *   WE are getting min RMSE value for both train & test data set for the 2nd degree polynomial
# *   Our R square is also good, for 2nd degree polynomial. Although getting better performance on test data in comparision to train data set.
# 
# =============================================================================
